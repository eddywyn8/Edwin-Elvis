# Study Harbor — Android App Project

This is a complete, ready-to-build Android Studio project that wraps the
Study Harbor web app in a native Android shell. All your data (profile,
photo, checklist, scores, tasks, streaks) is saved on the phone itself
using local storage — no internet connection needed, no server involved.

## How to get your .apk (about 10 minutes, one-time setup)

1. **Install Android Studio** (free): https://developer.android.com/studio
   — just click through the default installer options.

2. **Open this project**: launch Android Studio → "Open" → select the
   `StudyHarborApp` folder (the one containing this README).

3. Android Studio will say it's "Syncing Gradle" the first time — let it
   finish (it downloads the Android build tools automatically; needs
   internet for this one-time step only).

4. Once synced, go to the menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

5. When it finishes, click the **"locate"** link in the notification
   (or find it at `app/build/outputs/apk/debug/app-debug.apk`).

6. Copy that `.apk` file to your phone (via USB, email, Google Drive,
   whatever's easiest) and tap it to install. You may need to allow
   "install from unknown sources" the first time — Android will prompt
   you for this automatically.

That's it — Study Harbor is now a real app icon on your home screen,
works fully offline, and keeps its own data separate from the browser
version.

## If you want it on the Google Play Store later

This debug build is fine for personal use and sharing directly with
friends/students. Publishing to the Play Store requires a signed
"release" build and a Google Play Developer account (one-time $25 fee) —
Android Studio's **Build → Generate Signed Bundle / APK** wizard walks
you through creating a signing key when you're ready for that step.

## What's inside

- `app/src/main/assets/index.html` — the full Study Harbor app
- `app/src/main/java/.../MainActivity.java` — a WebView wrapper that
  loads it and enables local storage + the photo picker
- Standard Android Studio/Gradle project files

If you ever update the website content, just replace
`app/src/main/assets/index.html` with the new version and rebuild.
